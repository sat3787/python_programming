# Author: Kalepalli, Pavani Satish
# UBIT    : 50095672
# Email   : pavanisa@buffalo.edu
# Notes  : This file is compatible with Python 3.3.0 and
#	 may fail with other versions of python
#
# The diff command used in this program ignores spaces,cases and blank lines.
#  This was used to improve the effectives of the diff command

# Importing the packages required for the program
import os
import sys
import subprocess

# Fetch the list of files in the given directory or sub-directories
def Get_ListofFiles():
# Execute a find command to list all the files in the directory
	file_string=subprocess.getoutput("find . -type f -name '*'")
# Parse through the list of files and replace the escape sequence characters
	if len(file_string)!=0:
		file_string=file_string.replace("\n"," ")
		file_list=[]
		file_list=file_string.split()
		rd_flg=1
# Handle the error scenarios for failed command-line executions
	else:
		print("\n[Message]:Can not read the list of files in this folder\n")
		rd_flg=0
		
	return file_list,rd_flg

# Check if any of the files that are being compared already exist in the list of
# identical files. It returns a 0 if the filename already exists in the list.
def Check_Masterlist(file1,file2,master_list):
	stop_flg=0
	if len(master_list) >0:
		for i in range(len(master_list)):
			if file1 in master_list[i] or file2 in master_list[i]:
				stop_flg=1
				break
		if stop_flg!=1:
			return 1
		else:
			return 0				
	else:
		return 1

# Compute the list of identical files
def Get_Identical_Files(file_list):
	master_list,identical_files=[],set()
	for file1 in file_list:
		for file2 in file_list:
			if (Check_Masterlist(file1,file2,master_list)==1):
				if file1!=file2:
# Execute the diff command, ignore spaces, cases and blank lines while checking for differences					
					out=subprocess.getoutput("diff -ibBE "+file1+" "+file2)
					if len(out)==0:
						identical_files.update([file1,file2])
		if len(identical_files)>1:
			temp_list=[]
			for item in identical_files:
				temp_list.append(item)
			master_list.append(temp_list)
		identical_files.clear()
	if len(master_list)!=0:
		for sublist in master_list:
			sublist.sort()
		master_list.sort()
	return master_list

# Print the list of identical files
def Print_Output(master_list):
        if len(master_list)!=0:
                for i in range(len(master_list)):
                        print("[Message]:These files are identical:\n")
                        for j in range(len(master_list[i])):			
                                print(master_list[i][j]+"\n")
        else:
                print("\n[Message]:There are no identical files in the given directory or its subdirectories\n")

# Compute the list of files that were submitted after the given deadline
def Calc_Late_Submission(inp_month,inp_date,file_list,Calendar):
	late_submissions=[]
	for file in file_list:
		str1=subprocess.getoutput("ls -l "+file)
		longlist=[]
		longlist=str1.split()
		for month in Calendar.keys():
			for item in longlist:
				if month.lower()==item.lower():
					date=int(longlist[longlist.index(item) +1])
					if Calendar[month]>inp_month:
						late_submissions.append(file)
					elif Calendar[month]==inp_month:
						if date>inp_date:
							late_submissions.append(file)
					else:
                						pass
	late_submissions.sort()
	return late_submissions
					

def main():
# Part-1: Check for identical files
#---------------------------------------------
	print("\n[Message]:Welcome to the plagiarism checker app! Your current directory is :\n"+os.getcwd()+"\n")
	file_list,rd_flg=Get_ListofFiles()
	if rd_flg!=0:
		master_list=Get_Identical_Files(file_list)
		Print_Output(master_list)
# Part-2: Check for late submissions
#-------------------------------------------------
		Calendar=dict(Jan=1,Feb=2,Mar=3,Apr=4,May=5,Jun=6,Jul=7,Aug=8,Sep=9,Oct=10,Nov=11,Dec=12)
		while True:
			usr=input("\n[Action Required]:Enter a valid deadline in mm/dd format: ")
			usr_inp=usr.replace(" ","")
			if (len(usr_inp)==5) and (usr_inp[2]=="/"):
				usr_input=[]
				usr_input=usr_inp.split("/")
				if (1<=int(usr_input[0])<=12) and (1<=int(usr_input[1])<=31):
					inp_month=int(usr_input[0])
					inp_date=int(usr_input[1])
					break
		late_submissions=Calc_Late_Submission(inp_month,inp_date,file_list,Calendar)
		if len(late_submissions)>0:
			print("\n[Message]:The following files were submitted after the given deadline:\n")
			for i in late_submissions:
				print(i+"\n")
		
		else:
			print("\n[Message]:No files were submitted after the given deadline!\n")
		
                                        
		
		
# Execute the program                
main()
