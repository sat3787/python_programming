
#####################################################################
# File  : Project1.py
# Author: Kalepalli,Pavani Satish
# UBIT  : 50095672  
# MailID: pavanisa@buffalo.edu
# Course: CSE508 (summer 2014)
######################################################################
# command for running this script is: /usr/bin/python Project1.py 

import string
import sys
# user-defined function to count the number of words in the input file
# Accepts the content in the file as input argument and returns the 
# number of words and sorted list of most frequent words.
def count_words(data):
# store the special characters in a list so that they are ignored while counting
	char_to_ignore=[".",",","?",":",";","(",")","!"]
# intermmediate lists used for computation of counts
	wordlist,unique_list,freq_table=[],[],[]
# skip the special characters while counting the number of words; it helps in providing
# a cleaner display of output
	for things in char_to_ignore:
		if things not in data.lower():
	                continue
	        else:
	        	data=data.lower().replace(things," ")
# split the entire string using a space as a seperator
	wordlist=data.split()
	for item in wordlist:
	     	if item not in unique_list:
	        	unique_list.append(item)
	        	freq_table.append([item,wordlist.count(item)])
	op_table=sorted(freq_table,key=lambda name:name[1],reverse=True)
 	return (len(wordlist),op_table)

# user-defined function to count the number of characters in the input file
# Accepts the content in the file as input argument and returns the
# number of characters and list of frequencies of each character.
def count_characters(data):
	alphabets=string.ascii_lowercase
	ctr=0
	alpha_list=[]
	for i in data:
		if i==" ":
			continue
		ctr+=1
	data=data.lower()
	for char in alphabets:
		alpha_list.append([char,data.count(char)])
	return (ctr,alpha_list)	

# User-defined function to read the content from the input file
# The argument to this function is the name of the input file and the 
# return value is the content of the file.
def read_file(f_input):
	try:
		fh=open(f_input,'r')
		data=fh.read()
# handle exceptions due to read failure and display the appropriate message
	except IOError:
		print('\n[ERROR]- Cannot find the file or read content from the file!\n')
# If the user doesn't want to terminate the program incase of a read failure,accept a new file
# name for reading the content.Otherwise,terminate the program with a suitable message.
		val=" "
		while(val.lower()!='yes' and val.lower()!='no'):		
			val=raw_input('[ACTION REQUIRED]- Do you want to terminate\
 the program?(Enter yes/no):')
		if val.lower()=='no':
			flg=1
			data=" "
			return (flg,data)
		else:
			print('\n[MESSAGE]- Terminating the program . . .')			
			sys.exit(1)
# Display a success message if the file is read without errors 		
	else:
		print('\n[MESSAGE]- Input file was read successfully!\n')
		fh.close()
		flg=0
		return (flg,data)


# User-defined function to write the output generated from the program
# The input arguments of this function are the file name and computed values of
# counts and frequencies
def write_file(f_output,WordCount,MostFrequent,NonspaceCount,CharFreq):
	try:
		fh=open(f_output,'w')
		fh.write('\nThe total number of words in the given file are: '+str(WordCount)+'\n')
# If the number of different words in the input file are more than ten,log the list of words along
# with their frequencies.Otherwise,log a message that there are no ten diferent words in the given
# file. 
		if len(MostFrequent)>=10:
			fh.write('\nThe ten most frequently occurring words are as below\
:\n'+str('WORD').ljust(15)+'\t\tFREQUENCY\n')
			for i in range(0,10):
				fh.write(str(MostFrequent[i][0]).ljust(15)+'\t\t'+str(MostFrequent[i][1]).center(9)+'\n') 
		else:
			fh.write('\nThe given file does not have 10 or more different words\n')
# Log the number of non-whitespace characters in the given input file	
		fh.write('\nNumber of non-whitespace characters in the given file are: '+str(NonspaceCount)+'\n')
# Log the frequencies of each character along with its percentage form 
		fh.write('\nThe frequency of each alphabet is as below:\nALPHABET\tFREQUENCY\tPERCENTAGE(%)\n')
		for j in range(0,26):
			percent=100*float(CharFreq[j][1])/float(NonspaceCount)
			p="%.2f" % percent
			fh.write(str(CharFreq[j][0]).center(8)+'\t'+str(CharFreq[j][1]).rjust(9)+'\t'+str(p).center(13)+'\n')
# catch the write error exception and display the appropriate message to the user 
	except IOError:
		print('\n[ERROR]- Cannot create the output file or write content to the file!\n')
# If the user doesn't want to terminate the program incase of a write failure,accept a new file
# name for logging the output.Otherwise,terminate the program with a suitable message.
		val=" "
		while(val.lower()!='yes' and val.lower()!='no'):		
			val=raw_input('[ACTION REQUIRED]- Do you want to terminate\
 the program?(Enter yes/no):')
		if val.lower()=='no':
			oflg=1
			return oflg
		else:
			print('\n[MESSAGE]- Terminating the program . . .')			
			sys.exit(1)
# Display a success message incase there are no read and write errors
	else:
		print('\n[MESSAGE]- Output is generated and logged successfully!\n')
# close the file before terminating the program
		fh.close()
		oflg=0
		return oflg	


#Execution of the program starts here.The name of the input file is accepted from
#the user.The words and characters in the input file are counted by the corresponding
#functions and the output is logged in the file whose name is provided by the user. 
def main():
	flg,oflg=1,1
# reading the content from the input file
	while(flg!=0):		
		f_input=raw_input('\n[ACTION REQUIRED]- Enter the name of input file:')
		(flg,data)=read_file(f_input)
# computing the counts for words in the input file
	(WordCount,MostFrequent)=count_words(data)
# computing the counts for the characters in the input file
	(NonspaceCount,CharFreq)=count_characters(data)
	while(oflg!=0):	
# accept the name of the output file from the user
		f_output=raw_input('[ACTION REQUIRED]- Enter the name of output file:')
# log the output in the output file 
		oflg=write_file(f_output,WordCount,MostFrequent,NonspaceCount,CharFreq)
	print('[MESSAGE]- Program exited normally.\n')	


#Call the main function 	
main()






